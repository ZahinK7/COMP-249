package a3_file;
//-------------------------------------------------------
//Assignment 3
//Name(s) and ID(s) Sharjanan Premadas Staniculas(40114478) Zahin Khan(40060174)
/**
 * 
 * FileInvalidException is a subclass of Exception
 *
 */

public class FileInvalidException extends Exception{

	/**
	 * 
	 * Constructor with one argument
	 *
	 */

    public FileInvalidException (int i) {
        super("Problem detected with input file:Latex"+i+".bib");
    }




}