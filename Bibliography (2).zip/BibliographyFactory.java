package a3_file;
//-------------------------------------------------------
//Assignment 3
//Name(s) and ID(s) Sharjanan Premadas Staniculas(40114478) Zahin Khan(40060174)
//This program reads 10 files containing the bibliography of a book. Then, it 
//outputs to the console if the user wants to review it using 3 different format.
//-----------------------------------------------------


/**
* Importing files
* 
*/
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.FileReader;
import java.io.IOException;

public class BibliographyFactory {

	public static void main(String[] args) {
		/**
		 * Welcoming user to the program 
		 * 
		 */
     System.out.println("Welcome to the the Bibliography Factory made by Sharjanan and Zahin!");
    
		openInputFiles();
		openOutputFiles();
		processFilesForValidation();
		userFile();
	
		System.out.println("\nGoodbye!Hope you enjoyed creating the needed files using the Bibliography");
}
	static Scanner[] reader=new Scanner[10];
	static int numOfInvalidFiles;
	    static PrintWriter[]writerIEEE = new PrintWriter[10];
	    static PrintWriter[]writerACM = new PrintWriter[10];
	    static PrintWriter[]writerNJ = new PrintWriter[10];
	    static String pathIEEE = "C:\\Users\\Sharjanan\\Documents\\workspace\\a3_file\\IEEE";
	    static String pathACM ="C:\\Users\\Sharjanan\\Documents\\workspace\\a3_file\\ACM";
	    static String pathNJ = "C:\\Users\\Sharjanan\\Documents\\workspace\\a3_file\\NJ";
	    static String IEEE="",ACM="",NJ="";
	
	    /**
	     *Method used to read files (10 files)
	     * If the file cannot be opened, the system exit
	     * 
	     */
	    
	    public static void openInputFiles() {
		
		for(int i=0;i<10;i++) {
			String path= "Latex"+(i+1)+".bib";
			
			try
			{
				reader[i]=new Scanner(new FileInputStream(path));
			}
			catch(FileNotFoundException e) {
				System.out.println("Could not open input file Latex"+(i+1)+".bib for reading\n\nPlease check if file exist! Program will terminate after closing any opened files.");
			
				for(int z=0;z<i;z++){
				reader[z].close();
				}	
				System.exit(0);
			}
			
		}
	
	}
	
	    /**
	     * Method used to open json files
	     * Once an Exception is thrown, all files will be deleted
	     * 
	     */
	public static void openOutputFiles() {
		for (int i=0;i<10;i++) {
			try {
				
				writerIEEE[i]= new PrintWriter(new FileOutputStream(pathIEEE+(i+1)+".json"));
			    writerACM[i]= new PrintWriter(new FileOutputStream(pathACM+(i+1)+".json"));
			    writerNJ[i]= new PrintWriter(new FileOutputStream(pathNJ+(i+1)+".json")); 
			}
			
			catch(FileNotFoundException e) {
				System.out.println("Could not generate output file for Latex"+(i+1)+".bib");
				File[]fileIEEE = new File[10];
				File[] fileACM = new File[10];
				File[]fileNJ = new File[10];
				
				for (int j = 0; j<10;j++) {
					fileIEEE[j]= new File(pathIEEE+(j+1)+".json");
					if (fileIEEE[j].exists()) {
						if (writerIEEE[j]!=null)
							writerIEEE[j].close();
						fileIEEE[j].delete();
					}
					fileACM[j]= new File(pathACM+(j+1)+".json");
					if(fileACM[j].exists()) {
						if (writerACM[j]!=null)
							writerACM[j].close();
						fileACM[j].delete();
					}
					fileNJ[j]= new File(pathNJ+(j+1)+".json");
					if(fileNJ[j].exists()) {
						if (writerNJ[j]!=null)
							writerNJ[j].close();
						fileNJ[j].delete();
					}
				}
			for(int k = 0;i<10;i++)
				reader[k].close();
			System.exit(0);
			}
			
			
		}
	}
	
	/**
	 * Method as the name suggest, verify if the file are valid so that the formatting of the files can be done
	 * 
	 *
	 */
	
	public static void processFilesForValidation() {
		for(int i=0;i<10;i++) {
			reader[i].useDelimiter("=\\{\\}");
			String search=reader[i].next();
		
			
			try {
				if(reader[i].hasNext()) {
					numOfInvalidFiles++;
					throw new FileInvalidException(i+1);
				}
				else {
					createOutputFiles(i);
					
					writerIEEE[i].close();
                 writerACM[i].close();
                 writerNJ[i].close();
                 reader[i].close();
				}
			}
			 catch(FileInvalidException e) {
	                System.out.println("\nError: Detected empty field!");
	                System.out.println("=============================");
	                System.out.println(e.getMessage());
	                String invalidField =  search.substring(search.lastIndexOf("\n")+1);
	                System.out.println("File is invalid: Field \""+invalidField+"\" is empty. Processing stopped at this point. Other empty fields may be present as well!");
	                reader[i].close();
	                File[]toDelete = new File[3];
	                toDelete[0] =  new File(pathIEEE+(i+1)+".json");
	                toDelete[1] =  new File(pathACM+(i+1)+".json");
	                toDelete[2] =  new File(pathNJ+(i+1)+".json");

	                writerIEEE[i].close();
	                writerACM[i].close();
	                writerNJ[i].close();
	                toDelete[0].delete();
	                toDelete[1].delete();
	                toDelete[2].delete();


	            }
			
		}
		 System.out.println("\nA total of "+numOfInvalidFiles+" files were invalid, and could not be processed. All other "+(10-numOfInvalidFiles)+" \"valid\"files have been created.");		
	}
	
	
	/**
	 * Method that looks over the articles and uses other methods to convert the articles to the corrrect format
	 * 
	 *
	 */
	public static void 	createOutputFiles(int i) {
		for(int j=0;j<10;j++)
			reader[j].close();
		openInputFiles();
		reader[i].useDelimiter("@ARTICLE");
		int count=1;
		String author="",year="",journal="",title="",volume="",number="",pages="",doi="",month="",ISSN="";
		
		while(reader[i].hasNext()) {
			String article=reader[i].next();
			String [] articleLine=null;
			if(article.contains("\n"))
				articleLine=article.split("\n");
			else 
				continue;
			
			for(int k=0;k<articleLine.length;k++)
			{
				
				if(articleLine[k].contains("author=")) {
					author=articleLine[k];
					author=author.substring(author.indexOf("{"),author.indexOf("}"));
					author=author.replace("{", "");
					continue;
				}
				else if(articleLine[k].contains("year=")) {
					year=articleLine[k];
					year=year.substring(year.indexOf("{"),year.indexOf("}"));
					year=year.replace("{", "");
					continue;
				}
				else if(articleLine[k].contains("journal=")) {
					journal=articleLine[k];
					journal=journal.substring(journal.indexOf("{"),journal.indexOf("}"));
					journal=journal.replace("{", "");
					continue;
				}
				else if(articleLine[k].contains("title=")) {
					title=articleLine[k];
					title=title.substring(title.indexOf("{"),title.indexOf("}"));
					title=title.replace("{", "");
					continue;
				}
				else if(articleLine[k].contains("volume=")) {
					volume=articleLine[k];
					volume=volume.substring(volume.indexOf("{"),volume.indexOf("}"));
					volume=volume.replace("{", "");
					continue;
				}
				else if(articleLine[k].contains("number=")) {
					number=articleLine[k];
					number=number.substring(number.indexOf("{"),number.indexOf("}"));
					number=number.replace("{", "");
					continue;
				}
				else if(articleLine[k].contains("pages=")) {
					pages=articleLine[k];
					pages=pages.substring(pages.indexOf("{"),pages.indexOf("}"));
					pages=pages.replace("{", "");
					continue;
				}
				else if(articleLine[k].contains("doi=")) {
					doi=articleLine[k];
					doi=doi.substring(doi.indexOf("{"),doi.indexOf("}"));
					doi=doi.replace("{", "");
					continue;
				}
				else if(articleLine[k].contains("month=")) {
					month=articleLine[k];
					month=month.substring(month.indexOf("{"),month.indexOf("}"));
					month=month.replace("{", "");
					continue;
				}
				else if(articleLine[k].contains("ISSN=")) {
					ISSN=articleLine[k];
					ISSN=ISSN.substring(ISSN.indexOf("{"),ISSN.indexOf("}"));
					ISSN=ISSN.replace("{", "");
					
				}
				
			}
			
			IEEE=createIEEE(author,year,journal,title,volume,number,pages,month);
		
			writerIEEE[i].println(IEEE);
			
			ACM=createACM(author, year, journal, title, volume, number, pages, doi);
			writerACM[i].println("["+count+"]\t"+ACM);
			count++;
			
			NJ=createNJ(author,year, journal,title,volume, pages);
			writerNJ[i].println(NJ);
		}
	}
	
	
	/**
	 * Method that converts to ACM format
	 *
	 */
	private static String createACM(String author,String year,String journal,String title,String volume,String number,String pages,String doi) {

     String[]firstAuthor = author.split("and");

     return (firstAuthor[0]+"et al."+year+"."+title+"."+journal+"."+volume+","+number+"("+year+ ")," +pages + ". DOI:https://doi.org/"+doi+".");
 }
	/**
	 * Method that converts to IEEE format
	 *
	 */
	private static String createIEEE(String author,String year,String journal,String title,String volume,String number,String pages,String month) {

  author = author.replace("and", ",");

     return(author + ". \"" + title+ "\", "  + journal+ ", vol."+volume+",no."+number+",p."+pages+","+month+""+year+".");
 }

	/**
	 * Method that converts to NJ format
	 *
	 */
	private static String createNJ(String author,String year,String journal,String title,String volume,String pages) {

  author =  author.replace("and", "&");

  return(author+"."+title+"."+journal+"."+volume+","+pages+"("+year+").");
}
	
	/**
	 * Method that reads and display the file that is inputed by the user
	 *Program closes if user inputs wrong file
	 */
	public static void userFile() {
     Scanner input = new Scanner(System.in);
     String directory;
     String path = "C:\\Users\\Sharjanan\\Documents\\workspace\\a3_file";
     System.out.println("\nPlease enter the name of one of the files that you need to review:");
     directory = input.next();
     BufferedReader inputString= null;

     try {
         inputString = new BufferedReader(new FileReader(path+"\\"+directory));
         String stringObj = inputString.readLine();
         System.out.println("Here are the contents of the succesfully created file:"+directory+"\n");
     while(stringObj!=null) {
     System.out.println(stringObj);
     stringObj= inputString.readLine();
     }
     input.close();

     }catch (FileNotFoundException e) {
     System.out.println("Could not open desired file.File does not exist");
     System.out.println("\nHowver you will be given another chance to enter a valid file name.");
     System.out.println("\nPlease enter the name of one of the files you need to review:");
     directory=input.next();

     try {
         inputString = new BufferedReader(new FileReader(path+"\\"+directory));
         String stringObj = inputString.readLine();
         System.out.println("Here are the contents of the succesfully created file:"+directory+"\n");
     while (stringObj!=null) {
         System.out.println(stringObj);
         stringObj = inputString.readLine();
     }
         input.close();
     }catch(FileNotFoundException e1) {
         System.out.println("Could not open the input file again!The file does not exist or could not be created. Program will exit.");
         System.out.println();
     }catch (IOException e1) {
         System.out.println("Problem reading file");
     }
 }
     catch(IOException e) {
         System.out.println("Problem reading the file");
     }


 }
	
}
