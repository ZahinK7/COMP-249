package a4;

/**
 * Sharjanan Staniculas and Zahin Khan (40114478)(40060174)
 * @author Sharjanan Staniculas and Zahin Khan (40114478)(40060174)
 * Comp 249 Fall 2020
 * Assignment #4 Part 2
 * Cellphone class containning attributes such as brand, year, serial number and price.
 */

import java.util.Scanner;

public class Cellphone implements Cloneable {

	Scanner key = new Scanner(System.in);
	private long serialNum;
	private String brand;
	private int year;
	private double price;
	/**
	 * @param serial is the serial number of the cellphone
	 * @param brand2 is brand of the cellphone
	 * @param year2 is year of cellphone
	 * @param price2 is price of cellphone
	 */
	public Cellphone(long serial, String brand2,int year2,double price2) {
	this.serialNum=serial;
	this.brand=brand2;
	this.year=year2;
	this.price=price2;
	}
	
	public Cellphone(Cellphone cell, long serial2) {
		this.serialNum=serial2;
		this.brand=cell.brand;
		this.year=cell.year;
		this.price=cell.price;
		
		
		
	}
	/**
	 * getter
	 * @return the value of serial number of cellphone

	 */
	public long getserialNum() {
		return serialNum;
	}
	
	/**
	 * getter
	 * @return brand of cellphone
	 */
	
	public String getBrand() {
		return brand;
	}
	/**
	 * getter
	 * @return the year of cellphone
	 */
	public int getYear() {
		return year;
	}
	/**
	 * getter
	 * @return the price of cellphone
	 */
	
	public double getPrice() {
		return price;
	}
/**
 * setter
 * @param serialNum is serial number of cellphone
 */
	
	
	public void setserialNum(long serialNum) {
		this.serialNum = serialNum;
		
	}
	/**
	 * setter
	 * @param brand is brand of cellphone
	 */
	
	public void setBrand(String brand) {
		this.brand = brand;
	}
	/**
	 * setter
	 * @param year is year of cellphone
	 */
	
	public void setYear(int year) {
		this.year=year;
	}
	/**
	 * setter
	 * @param price isprice of cellphone
	 */
	
	public void setPrice(double price) {
		this.price=price;
	}
	
	public String toString() {
		return "["+serialNum+ " : "+ brand+" "+price+"$ "+year+"]";
	}
	/**
	 * To String method
	 * @return prints all attribute of the class cellphone which has been stored
	 */
	public boolean equals (Object o1) {
		if (this==o1)
			return true;
		if (o1 == null)
			return false;
		if(getClass()!=o1.getClass())
			return false;
		Cellphone o2= (Cellphone)o1;
		if(brand == null) {
			if(o2.brand != null)
				return false;
		} else if (!brand.equals(o2.brand))
		return false;
		if(Double.doubleToLongBits(price) != Double.doubleToLongBits(o2.price))
		return false;
		if(year != o2.year)
		return false;
		return true;
	
	}
	
	/**
	 * Cloning cellphone
	 */
	public Object clone() {

	long serialNumb = serialNum*10;
	return new Cellphone (this,serialNumb);
	}
	
	
	
	
}