package a4;

/**
 * Sharjanan Staniculas and Zahin Khan (40114478)(40060174)
 * @author Sharjanan Staniculas and Zahin Khan (40114478)(40060174)
 * Comp 249 Fall 2020
 * Assignment #4 Part 2
 * This class allows the reading of files and creates a copy
 */

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class CelllistUtilization {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Celllist celll1= new Celllist();
		Celllist celll2 = new Celllist();
		
		
		
		Scanner key1 = new Scanner(System.in);
		Scanner key2 = null;
		long serialn;
		String brand;
		
		int year;
		double price;
		/**
		 * @param key1 used to store user input
		 * @param key2
		 * @param serialn is the serial number of cellphone
		 * @param brand of cellphone
		 * @param year of cellphone
		 * try/catch used to prevent errors if any occurs
		 */
		
		
		try {
			key2 = new Scanner(new FileInputStream("Cell_Info.txt"));
			while(key2.hasNext()) {
				serialn=key2.nextLong();
				brand = key2.next();
				
				price=key2.nextDouble();
				year=key2.nextInt();
				celll1.addToStart(new Cellphone(serialn,brand,year,price));
				
			}
			
		key2.close();
		celll1.showContents();
			
		System.out.println("Enter a serial number to search: ");
		
		long serialnum2 = key1.nextLong();
		celll1.find(serialnum2);
		
		celll1.addToStart(new Cellphone(1101101,"Sony",2008,23.30));
		celll1.showContents();
		
		celll1.deleteFromStart();
		celll1.showContents();
		
		celll1.insertAtIndex(20, new Cellphone(8996161,"ASUS",2014,600.69));
		celll1.showContents();
		celll1.deleteFromIndex(12);
		celll1.showContents();
		
		celll1.replaceAtIndex(15, new Cellphone(53180008,"LG",2018,900.99));
		celll1.showContents();
		celll1.find((long)4900088);
		System.out.println(celll1.contains((long)7559090));
		celll1.showContents();
		
		celll2=celll1.clone();
		System.out.println("Its "+celll1.equals(celll2)+" that its equal");
		celll2.showContents();	
		}
		catch(FileNotFoundException e) {
			System.out.println("File does not exist in path");
		}		
		System.out.println("Thanks for using the program");
	}
	
}
