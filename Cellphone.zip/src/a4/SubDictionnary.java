package a4;
/**
 * Sharjanan Staniculas and Zahin Khan (40114478)(40060174)
 * @author Sharjanan Staniculas and Zahin Khan (40114478)(40060174)
 * Comp 249 Fall 2020
 * Assignment #4 Part 1
 * This class reads a file and writes to an another file all words in an alphabetic order.
 */

import java.util.ArrayList;
	import java.util.Scanner;
	import java.io.PrintWriter;
	import java.io.FileOutputStream;
	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	
public class SubDictionnary {
/**
 * initializing variables
 * @out is Printwritter object to print inside the file
 * @read is a Scanner object to read the the screen
 * @r  is a scanner to read the file
 * @words is a ArrayList to store words in a list
 */
	static PrintWriter out=null;
	static Scanner read =new Scanner(System.in);
	static Scanner r=null;
	static ArrayList<String> words =new ArrayList <String>();
	
public static void main(String[] args) {
		System.out.println("Please enter file name: ");
		/**
		 * Entering filename to check
		 * @filename is the name of file
		 */
		String fileName=read.nextLine();
		try
		{
			r=new Scanner(new FileInputStream(fileName));
			out=new PrintWriter(new FileOutputStream("SubDictionary.txt"));
			read(r);
			writer(out);

			out.flush();
			out.close();
			r.close();
			
			
		
		}
		/**
		 * if file not found
		 * @e is the exception when file not found
		 */
		catch(FileNotFoundException e) {
			System.out.println("File: "+ fileName+" could not be found.");
		}
		
}
/**
 * saving words in array list
 * @param w is the words 
 * @param temp is the String that's going to have no space(trimmed)
 */
public static void saving(ArrayList<String> w,String temp) {
	temp=temp.toUpperCase();
	
	if(temp.contains("0")||temp.contains("1")||temp.contains("2")||temp.contains("3")||temp.contains("4")||temp.contains("5")||temp.contains("6")||temp.contains("7")||temp.contains("8")||temp.contains("9"))
	return;
	else if(temp.contains(".")){
		w.add(temp.replace(".", ""));
	}
	else if(temp.contains(",")){
		w.add(temp.replaceAll(",", ""));
	}
	else if(temp.contains("?")){
		w.add(temp.replace("?", ""));
	}
	else if(temp.contains(":")){
		w.add(temp.replaceAll(":", ""));
	}
	else if(temp.contains("�")){
		w.add(temp.substring(0, temp.length()-2));
	}
	else if(temp.contains("=")){
		w.add(temp.replaceAll("=", ""));
	}
	else if(temp.contains(";")){
		w.add(temp.replaceAll(";", ""));
	}
	else if(temp.contains("!")){
		w.add(temp.replaceAll("!", ""));
	}
	else if(temp.charAt(0)=='A'){
		w.add(temp);
	}
	else if(temp.charAt(0)=='I'){
		w.add(temp);
	}
	else if(temp.length()!=1){
		w.add(temp);
	}
}
/**
 * Reads from a file
 * @param s is a Scanner object which is used to read from file
 */
public static void read(Scanner s) {
	String temp="";
	temp=s.next().trim();
	
	
	while(s.hasNext()) {

		saving(words,temp);
		temp=s.next().trim();
		
	}
	words.sort(String::compareToIgnoreCase);
	
	Object[] stA=words.toArray();
	for(Object str :stA) {
		if(words.indexOf(str)!=words.lastIndexOf(str)) {
			words.remove(words.lastIndexOf(str)).trim();
		}
	}
	
	
}
/**
 *This method  writes in the SubDictionnary.txt file
 * @param f is the file for writting the outputs
 */
public static void writer(PrintWriter f) {
	String s;
	char c='A';
	char c1;
	f.println("The document produced this sub-dictionary, which includes "+ words.size() + " entries.");
	f.println("A");
	f.println("==");
	
	for(int i=1;i<words.size();i++) {
		s=words.get(i).trim();
		c1=s.charAt(0);
		
		if(c1!=c) {
			f.println("\n"+c1);
			f.println("==");
			c=c1;
			

		}
		f.println(words.get(i).trim());
		
	}
	
}

}
