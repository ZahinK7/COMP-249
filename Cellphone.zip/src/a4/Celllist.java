package a4;

/**
 * Sharjanan Staniculas and Zahin Khan (40114478)(40060174)
 * @author Sharjanan Staniculas and Zahin Khan (40114478)(40060174)
 * Comp 249 Fall 2020
 * Assignment #4 Part 2
 * This class create class wich contains cellphones
 */

import java.util.NoSuchElementException;

public class Celllist implements Cloneable {

	
	private class Cellnode implements Cloneable{
		/**
		 * Attributes
		 * @param cell is aitem
		 * @param node is a link
		 */
		private Cellphone cell;
		private Cellnode node;
		/**
		 * Constructor 
		 * @param cell2 is a item
		 * @param cell3 is a link
		 */
		
		public Cellnode(Cellphone cell2, Cellnode cell3) {
			this.cell =cell2;
			this.node = cell3;
		}
		/**
		 * Default Constructor
		 */
		
		public Cellnode() {
			cell=null;
			node=null;
		}
		
		/**
		 * Copy Constructor
		 * @param node2 is a link
		 */
		public Cellnode(Cellnode node2) {
			this.node = node2.node;
		}
		
		/**
		 * cloning the link
		 */
		public Object clone() {
			return new Cellnode(this);
		}
		
		/**
		 * Getters
		 * @return cell is returning the item
		 */
		public Cellphone getCell() {
			return cell;
		}
		/**
		 * Getters
		 * @return node is returning the link
		 */
		public Cellnode getNext() {
			return node;
		}
		/**
		 * Setters
		 * @param cell2  setting the item
		 */
		public void setCell(Cellphone cell2) {
			this.cell=cell2;
		}
		/**
		 * setters
		 * @param node2 setting the link
		 */ 
		public void setNode(Cellnode node2) {
			this.node=node2;
		}
		
	}
	
	private Cellnode head;
	private int size;
	/**
	 * Default Construct
	 */
	public Celllist() {
		head =  null;
		size=0;
	}
	
	public Celllist (Celllist celll) {
		if (celll== null)
			throw new NullPointerException();
		if(celll.head==null)
			head=null;
		else {
			head=copyList(celll.head);
			}
	}
	/**
	 * Cloning
	 */
	
	public Celllist clone() {
		try {
			Celllist celll2=(Celllist)super.clone();
			if (head==null)
				celll2.head=null;
			else celll2.head=copyList(head);
			return celll2;
		}
		catch(CloneNotSupportedException e) {
			return null;
		}
	}
	/**
	 * copying list
	 * @param node3
	 * @return new list
	 */
	private Cellnode copyList (Cellnode orr) {//Privacy leak 
		Cellnode temp = orr;
		Cellnode newHead = null;
		Cellnode end = null;
		
		newHead = new Cellnode((Cellphone)(temp.cell).clone(),null);
		 end=newHead;
		 temp=temp.node;
		 
		 while(temp!=null) {
			 end.node= new Cellnode((Cellphone)(temp.cell).clone(),null);
			 end=end.node;
			 temp=temp.node;
			 
		 }
		return newHead;
	}
/**
 * Adds item to start
 * @param cell3 item
 */
	public void addToStart(Cellphone cell3) {
		Cellnode node5 = new Cellnode(cell3, head);
		head = node5;
		node5=null;
	}
	/**
	 * Insert item to a desired index
	 * @param num is used as counter
	 * @param cell$ is the cellphone item
	 * @throws NoSuchElementException
	 */
	
	public void insertAtIndex(int num,Cellphone cell4)throws NoSuchElementException{
		int index = 0;
		if(head==null) {
			System.out.println("List is empty"+num+"cannot find in list");
			
			
		throw new NoSuchElementException();
		}
		if(index==num) {
			head = new Cellnode(cell4,head);
			System.out.println("Added at index"+num);
			return;
		}
		/**
		 * 
		 */
	Cellnode node5= head;
	while(node5 != null && index !=num) {
		index++;
		
		if(node5.node==null) {
			System.out.println(num+"cannot find in list");
			throw new NoSuchElementException();
		}
	if(index ==num) {
		node5.node=new Cellnode(cell4,node5.node);
		System.out.println("Added at index"+num);
	}
	node5=node5.node;
	}
	
	}
/**
 * 
 * @param num is the index at which the item is deleted
 * @throws NoSuchElementException
 */
	public void deleteFromIndex(int num)throws NoSuchElementException{
		if (head==null) {
			System.out.println("Life is empty");
			throw new NoSuchElementException();
		}
	Cellnode node6 = head;
	
	if(num==0) {
		head=node6.node;
		System.out.println("Deleted at"+num);
		return;
	}
	for(int i=0;node6!=null && i<num-1;i++)
		node6=node6.node;
	
	if(node6==null||node6.node==null) 
		return;
		
		
		Cellnode node = node6.node.node;
		System.out.println("Deleted at"+num);
		
		node6.node=node;
	}
	/**
	 * Deletes a list item in the beginning
	 */
	public void deleteFromStart()throws NoSuchElementException{
		if(head==null) {
			System.out.println("List is empty");
			throw new NoSuchElementException();
			
		}
	head=head.node;
	System.out.println("Deleted at 0");
	return;
	}
	/**
	 * Replacing an item with another
	 * @param num is the index for which an item is replaced
	 * @param cell5 is a the item which the index is replaced by
	 * @throws NoSuchElementException
	 */
	public void replaceAtIndex(int num, Cellphone cell5)throws NoSuchElementException{
        int index=0;
        if(head==null) {
            System.out.println("List is empty"+num+"cannot find in list");
            throw new NoSuchElementException();
        }
    if(index==num) {
        head= new Cellnode(cell5,head.node);
        System.out.println("Replaced at index"+num);
return;
    }
    Cellnode node6 = head;

    while(node6 != null && index != num) {
        index++;
        if(node6.node==null) {
            System.out.println(num+ "not found in list");
            throw new NoSuchElementException();
        }
        if(index==num) {
            node6.node= new Cellnode(cell5,node6.node);
            System.out.println("Replaced at index "+ num);
        }
     node6=node6.node;
    }
    Cellnode node7=head;
    for(int j=0;node7!=null&&j<num;j++)
        node7=node7.node;
    if(node7==null||node7.node==null)
        return;
    Cellnode node = node7.node.node;
    node7.node=node;


    }
	/**
	 * Finds the item with serial number
	 */
	
	public Cellnode find(Long serial) {
		int counter=0;
		if (head==null) {
		System.out.println("List is empty");
		return null;
		}
	Cellnode pointer = head;
	while(pointer!=null) {
		if (pointer.cell.getserialNum()==serial) {
		System.out.println("Serial number:"+serial+"was found. Number of Iterations before"+serial+"was found"+counter);
		return pointer;
		}
	pointer=pointer.node;
	counter++;
	}
	System.out.println("Serial number:"+serial+"was not found");
	return null;
	
	}
	/**
	 * Returns if the serial number exists in the list
	 * @param serial is the serial number 
	 * @return true/false
	 */
	public boolean contains(long serial) {
		if(head==null) {
			System.out.println("List is empty");
			return false;
		}
		Cellnode pointer = head;
		while(pointer != null) {
		if (pointer.cell.getserialNum()==serial) {
		return true;
			}
			pointer=pointer.node;
		}
	return false;
	}
	/**
	 *Shows the content of list
	 */
	public void showContents() {
		Cellnode node7=head;
		if(node7==null)
			System.out.println("Nothing to display");
		else {
			System.out.println("The current size of the list is "+length()+"Here are the contents of list");		
		}
		int count=0;
		while(node7 !=null) {
			if (count==3) {
				System.out.println();
				count=0;
			}
			System.out.println(node7.cell+"--->");
			count++;
			node7=node7.node;
		}
		System.out.println("X");
		System.out.println();
		
	}
	/**
	 * 
	 * @return the size of list
	 */
	public int length() {
		size=0;
		Cellnode node7 = head;
		while(node7 != null) {
			size++;
			node7=node7.node;
		}
		return this.size;
	}
	public boolean equals(Celllist c) {
		if (this==c) {
			return true;
		}
		if(c instanceof Celllist) {
			Celllist celi = (Celllist) c;
			int n= length();
			if(n==celi.length()) {
				Cellnode node8 = head;
				Cellnode node9 = celi.head;
				while(node8!=null) {
					if((node8.cell.getBrand()!=node9.cell.getBrand())&&(node8.cell.getPrice()!=node9.cell.getPrice()&&(node8.cell.getYear()!=node9.cell.getYear()))){
					return false;	
					}
					node8=node8.node;
					node9=node9.node;
				}
				return true;
			}
	     	}
		return false;
	}
	}
	