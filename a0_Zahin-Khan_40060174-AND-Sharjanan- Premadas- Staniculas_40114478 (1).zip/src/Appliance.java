// -------------------------------------------------------
//Name(s) and ID(s) Sharjanan Premadas Staniculas(40114478) Zahin Khan(40060174)
//COMP249
//Assignment # 1
//Due Date Friday, October 02, 2020
 //----------------------------------------------------

/**
 * Name(s) and ID(s) Sharjanan Premadas Staniculas(40114478) Zahin Khan(40060174)
 * COMP249
 * Assignment # 1
 * Due Date Friday, October 02, 2020
 * This program allows the use of attributes and methods of appliance in order to compare or store information
 */

public class Appliance{
	/**
	*Declaring attributes
	* @param type is the type of appliance
    * @param brand is the name of the brand of the appliance
	* @param price is the price of the appliance
	* @param srl_num is the serial number of the appliance
	*/
	private String type,brand;
	private long srl_num;
	private double price;
	private static int numAppliance=0; 

	
	
	
	public Appliance() {
		type="";
		brand="";
		srl_num=1000000+numAppliance++;
		price=1;
		;
	}
	
	/**
	*Constructor that takes 3 values
	*@param t is the type of appliance
	*@param b is the brand of the appliance
	*@param p is the price of the appliance
	*/
	public Appliance(String t, String b, double p) {  
		boolean valid;
		valid=typeOk(t);
		if (valid) {
		this.type=t;
		this.brand=b;         				
		/**
		*Serial number start at 1000000 and increase by number of appliances
		*Makes sure also that the price is not less than 1$ in the following if statement
		*/
		this.srl_num=1000000+numAppliance++;  
		if(p<1) {                              
			System.out.println("The price of an appliance cannot be less than 1$");
		}
			else
			this.price=p;
		}
		else
			System.out.println("Not valid type");
	}
	
	/**
	*copy constructor
	*
	*/
	
	public Appliance(Appliance anApp)
	/**
	 * @param for anApp  used for copy constructor
	 */
	
	{  
		if(anApp==null)System.exit(0);
		this.type=anApp.type;
		this.brand=anApp.brand;
		this.srl_num=anApp.srl_num+numAppliance++;
		this.price=anApp.price;
	}
	
	/**
	*method used to determine whether inputed correct type of appliance in program
	*
	*/	
	private boolean typeOk(String t) {
		boolean valid;
		if(t.equalsIgnoreCase("Fridge"))
			return valid=true;
		else if(t.equalsIgnoreCase("Washer"))
			return valid=true;
		else if(t.equalsIgnoreCase("Dryer"))
			return valid=true;
		else if(t.equalsIgnoreCase("Freezer"))
			return valid=true;
		else if(t.equalsIgnoreCase("Stove"))
			return valid=true;
		else if(t.equalsIgnoreCase("Dishwasher"))
			return valid=true;
		else if(t.equalsIgnoreCase("Water Heaters"))
			return valid=true;
		else if(t.equalsIgnoreCase("Microwave"))
			return valid=true;
		else
			return valid=false;
	}  /**
	   *@return
	   */
	

	/**
	*accessors(getters) for the following variables (type of appliance,brand name, serial number of appliance and price of appliance)
	*@return the type of appliance
	*@return the brand name of the appliance
	*@return the serial number of the appliance
	*@return the price of the appliance
	*/	
	public String getType() {
		return type;	
	}
	public String getBrand() {
		return brand;
	}
	public long getSerial_num() {
		return srl_num;
	}
	public double getPrice() {
		return price;
	}
	public static int findNumberOfCreatedAppliances() {
		 return numAppliance;
	 }

	/**
	*mutators(setters)for the following variables (type of appliance,brand name, serial number of appliance and price of appliance)
	*@param t is the type of appliance
	*@param b is the brand name of the appliance
	*@param p is the price of the appliance
	*/	
	
	public void setType(String t) {
		type=t;
	}
	public void setBrand(String b) {
		brand=b;
	}
	public void setPrice(double p) {
		price=p;
	}
	
	/**
	 * Comparing the appliances based on brand,type and price with the following method
	 */
	public boolean equals(Appliance anotherApp) { 
	if(this.type.equals(anotherApp.getType()) && this.brand.equals(anotherApp.getBrand()) && this.price==anotherApp.getPrice())
		return true;
	else return false;
	}
	
	/**
	 * toString method that display the information about the appliance
	 */
	public String toString() {
		return "Type: "+type+"\nBrand: "+brand+"\nSerial Number: "+srl_num+"\nPrice: "+price+"\n\n";
	}
}