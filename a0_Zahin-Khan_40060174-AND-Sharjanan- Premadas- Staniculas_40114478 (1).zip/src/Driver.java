// -------------------------------------------------------
//Name(s) and ID(s) Sharjanan Premadas Staniculas(40114478) Zahin Khan(40060174)
//COMP249
//Assignment # 1
//Due Date Friday, October 02, 2020
 //----------------------------------------------------

/**
 * Name(s) and ID(s) Sharjanan Premadas Staniculas(40114478) Zahin Khan(40060174)
 * COMP249
 * Assignment # 1
 * Due Date Friday, October 02, 2020
 * This program is a driver to allows us to use appliance.java file
 */

import java.util.Scanner;
public class Driver {

	public static void main(String[] args) {




		System.out.println("*******************Welcome To Appliance Manager*********************");

		
		/**
		 * Prompt user to enter information for appliances
		 */
		Scanner keyIn=new Scanner(System.in);
		final String password="a";

		System.out.println("How many appliance do you wish the store to contain?");
		int maxApp=keyIn.nextInt();
		Appliance [] inventory= new Appliance [maxApp];

		int option=getChoice();
		int attempt=0;
		int maxAttempt=0;
		int i=0;

		/**
		 * Brings user to main menu and prompts user to choose with a while-loop
		 */
		while(option!=5)
		{
			while(option==1) {
				System.out.println("Please enter the password: ");
				String userPass=keyIn.next();
				attempt=1;

				while(attempt<=3 && (password.equals(userPass))==false) {
					attempt++;
					if(attempt==4)
					{
						System.out.println("You failed 3 times.");

						maxAttempt+=attempt-1;

					}
					else {
						System.out.print("Error!Wrong password.\nPlease re-enter the password: ");
						userPass=keyIn.next();
					}

				}

				/**
				 * if statement that determines if the password is valid
				 */
				if((password.equals(userPass))==true) {
					attempt=0;maxAttempt=0;

					System.out.println("How many appliance(s) do you want to enter: ");
					int app=keyIn.nextInt();
					if(inventory.length<app)
						System.out.println("The maximum remaining places in the arr is zero");
					else {

						addAppliance(inventory,app);
						i+=app;
						for(int s=0;s<app;s++)
							System.out.println(inventory[s]);

					}
				}

				if(maxAttempt==12) {
					System.out.println("Program detected suspicious activities and will terminate immediately!");
					System.exit(0);
				}
				else {	
					option=getChoice();
					break;
				}


			}
			/**
			 * while loop that prompts user for the secondary menu
			 */
			
			while(option==2) 
			{
				System.out.println("Please enter the password: ");
				String userPass=keyIn.next();
				attempt=1;

				while(attempt<=3 && (password.equals(userPass))==false) {
					attempt++;
					if(attempt==4)
						System.out.println("You failed 3 times.");
					else {
						System.out.print("Error!Wrong password.\nPlease enter the password: ");
						userPass=keyIn.next();
					}
				}
				if(attempt==4) {
					option=getChoice();
					break;
				}
				
				while((password.equals(userPass))==true) 
				{

					System.out.println("Enter the serial number you wish to update: ");
					long serial_num=keyIn.nextLong();
					int numb;
					int m=0;		
					for(m=0;m<i;m++) 
					{

						if(serial_num==inventory[m].getSerial_num()) 
						{

							numb=getChoice2();
							while(numb!=4) {
								if(numb==1) { 
									System.out.println("Enter the new brand name");
									String b1 = keyIn.next();
									inventory[m].setBrand(b1);
									System.out.println(inventory[m]);

								}
								else if(numb==2){
									System.out.println("Enter the new type name");
									String t1 = keyIn.next();
									inventory[m].setType(t1);
									System.out.println(inventory[m]);

								}
								else if(numb==3) {
									System.out.println("Enter the new price");
									double p1 = keyIn.nextDouble();
									inventory[m].setPrice(p1);
									System.out.println(inventory[m]);
								}
								numb=getChoice2();

							}

                          

						}
						break;
					}
					while(m==i) {
						System.out.println("There's no such serial number found in the inventory. Would you like to re-enter another serial number or quit to the main menu.");
						System.out.println("Enter the serial number you wish to update: ");
						serial_num=keyIn.nextLong();
						m=0;
					}

					option=getChoice();
					break;

				}   
			}

			while(option==3) {
				findApplianceBy(inventory,i);
				option=getChoice();
				break;
			}

			while(option==4) {
				findCheaperThan(inventory,i);
				option=getChoice();
				break;
			}

		}




		System.out.println("Thank you for using the program. Good bye");	
	}





	/**
	 * Static method for first menu
	 */

	public static int getChoice() {
		int choice;
		System.out.println("What do you want to do?");
		System.out.println("\t1. Enter new appliances (password required)");
		System.out.println("\t2. Change information of an appliance (password required)");
		System.out.println("\t3. Display all appliances by a specific brand");
		System.out.println("\t4. Display all appliances under a certain a price.");
		System.out.println("\t5. Quit");
		System.out.println("Please enter your choice>");

		Scanner input=new Scanner(System.in);
		choice=input.nextInt();
		while(choice<1||choice>5) {
			System.out.println("Error! Wrong entry, make sure your input corresponf to the menu.");
			System.out.println("Please enter your choice>");
			choice=input.nextInt();
		}
		return choice;


	}
	/**
	 * Static method for secondary menu once user has entered choice number 2
	 */
	public static int getChoice2() {
		int choice2;
		System.out.println("What would you like to change?");
		System.out.println("\t1. Brand");
		System.out.println("\t2. Type");
		System.out.println("\t3. Price");
		System.out.println("\t4. Quit");
		System.out.println("Please enter your choice>");
		Scanner input2=new Scanner(System.in);
		choice2=input2.nextInt();
		while(choice2<1||choice2>4) {
			System.out.println("Error! Wrong entry, make sure your input corresponf to the menu.");
			System.out.println("Please enter your choice>");
			choice2=input2.nextInt();
		}
		return choice2;
	}
	
	/**
	 * Static method to change information of the appliance
	 */
	public static void changeAppliance(Appliance[] storage) {
		System.out.println("Please enter your serial number: ");
		Scanner input5 = new Scanner(System.in);
		long serial_number = input5.nextLong();
		int z = 0;
		for(z=0;z<storage.length;z++) {
			if (storage[z].getSerial_num()==serial_number) {
				System.out.println(storage[z]);
				break;
			}
		}
		while (z==storage.length) {
			System.out.println("The given serial number:"+ serial_number+" is not found");
			System.out.println("Do you want to quit and return to the main menu?(yes or no)");
			char ch = input5.next().charAt(0);
			if (ch == 'n') {
				return;
			}
			System.out.println("Please enter the serial number: ");
			serial_number=input5.nextLong();
			for (z=0;z<storage.length;z++) {
				if(storage[z].getSerial_num()==serial_number) {
					System.out.println(storage[z]);
					break;
				}
			}
		}
		while(true) {
			System.out.println("What would you like to change?");
			System.out.println("\t1. Brand");
			System.out.println("\t2. Type");
			System.out.println("\t3. Price");
			System.out.println("\t4. Quit");
			System.out.println("Please enter your choice>");
			int choice5 = input5.nextInt();
			while(choice5 <1 || choice5 > 4) {
				System.out.println("Error! Number must be between 1-4");
				System.out.println("Enter your choice>");
				choice5 = input5.nextInt();
			}
			System.out.println();
			if (choice5==1) {
				System.out.println("Enter new brand name: ");
				String brand = input5.nextLine();
				storage[z].setBrand(brand);
			}
			else if (choice5==2) {
				System.out.println("Enter new type: ");
				String type = input5.nextLine();
				storage[z].setType(type);
			}
			if (choice5==1) {
				System.out.println("Enter new price: ");
				double price = input5.nextDouble();
				storage[z].setPrice(price);
			}else { break;
			}
		}
	}
	
	/**
	 * static method to add new information on appliance
	 */
	public static void addAppliance(Appliance [] storage,int app1) {	
		Scanner input6=new Scanner(System.in);

		while(app1<0) {
			System.out.println("Error! The number of appliance must be positive.");
			System.out.println("How many appliance(s) do you want to add:");
			app1=input6.nextInt();
		}
		if(storage.length<app1)
			System.out.println("The maximum places in the iventory is fully reached.");
		else {

			for (int j=0;j<app1;j++) {
				System.out.println("Enter the type of appliance: ");
				String type1=input6.next();
				System.out.println("Enter the brand of the appliance: ");
				String brand1=input6.next();
				System.out.println("Enter the price of the appliance: ");
				Double price1=input6.nextDouble();
				input6.nextLine();

				storage[j]=new Appliance(type1,brand1,price1);

			}
		}
	}

	/**
	 * Static method if the user chooses to find specific brand applaince
	 */
	public static void findApplianceBy(Appliance [] storage,int i) {
		boolean c=false;
		System.out.println("Please enter a brand name: ");
		Scanner input3=new Scanner(System.in);
		String userBrand1= input3.next();
		for (int j=0;j<i;j++) {
			c=true;
			if(userBrand1.equalsIgnoreCase(storage[j].getBrand()))
				System.out.println(storage[j]);
		}
		if(c==false)
			System.out.println("Brand "+userBrand1+" not found.");

	}
	
	/**
	 * Static method for finding price under the given price of the user
	 */
	public static void findCheaperThan(Appliance[]storage,int i) {
		boolean f =false;
		System.out.println("Please enter a price: ");
		Scanner input4=new Scanner(System.in);
		double cheapPrice=input4.nextDouble();
		for (int k=0;k<i;k++) {
			f =true;
			if (storage[k].getPrice()<cheapPrice) {
				System.out.println(storage[k]);
			}
		}
		if(f==false) {
			System.out.println("No appliance found with price given");
		}
		System.out.println();
	}

	public static Appliance addApp(){
		Scanner input1=new Scanner(System.in);
		Appliance object=new Appliance("fridge","lg",1000);
		return object;


	}

}

