// -------------------------------------------------------
//Name(s) and ID(s) Sharjanan Premadas Staniculas(40114478) Zahin Khan(40060174)
//COMP249
//Assignment # 2
//Due Date Friday, October 23, 2020
 //----------------------------------------------------
/**
 * Name(s) and ID(s) Sharjanan Premadas Staniculas(40114478) Zahin Khan(40060174)
 * COMP249
 * Assignment # 2
 * Due Date Friday, October 23, 2020
 * This program stores data of different type of flying object and helps understand why the clone methode should be used over the 
 * copy constructor.
 */
/**
 * This java file is in the UAV package and importing the super class FlyingObject
 */
package UAV;
import Part1.FlyingObject;

public class UAV extends FlyingObject {
	/**
	 * Declaring Attributes
	 * @param weight is the weight of UAV
	 * @param price is the price of the UAV
	 */
	protected double weight;
	protected double price;
	
	/**
	 * Default constructor
	 */
	public UAV() {
		weight=0;
		price=0;
	}
	/**
	 * Constructor that take 2 values
	 * @param weight is the weight of UAV
	 * @param price is the price of the UAV
	 */
	public UAV(double weight, double price) {
		this.weight = weight;
		this.price = price;
	}
	
	/**
	 * Copy Constructor
	 * @param u1 is the object UAv used to do the copy constructor
	 */
	public UAV(UAV u1) {
		this.weight = u1.weight;
		this.price=u1.price;
	}
	
	public double getWeight() {
		return weight;
	}
	
	public double getPrice() {
		return price;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	public void setPrice(double price) {
		this.price=price;
	}
	/**
	 * @return a message with price and weight
	 */
	public String toString() {
		return "This UAV has a weight of "+weight+"pounds and a price of "+price+".";
	}
	/**
	 *@return if two UAV are the same by considering the weight and price
	 */
	public boolean equals( UAV o) {
		if(this == o)
			return true;
		if(o==null)
			return false;
		if (getClass()!= o.getClass())
			return false;
		UAV other = (UAV) o;
		if (Double.doubleToLongBits(price)!=Double.doubleToLongBits(other.price))
			return false;
		if (Double.doubleToLongBits(weight)!=Double.doubleToLongBits(other.weight))
			return false;
		return true;
		
	}
}
