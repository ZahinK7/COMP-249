// -------------------------------------------------------
//Name(s) and ID(s) Sharjanan Premadas Staniculas(40114478) Zahin Khan(40060174)
//COMP249
//Assignment # 2
//Due Date Friday, October 23, 2020
 //----------------------------------------------------
/**
 * Name(s) and ID(s) Sharjanan Premadas Staniculas(40114478) Zahin Khan(40060174)
 * COMP249
 * Assignment # 2
 * Due Date Friday, October 23, 2020
 */
package Part1;
import Airplane.airplane;
import Helicopter.helicopter;
import Helicopter.quadcopter;
import Multirotor.multirotor;
import UAV.UAV;
import AgriculturaldroneandMav.agriculturaldrone;
import AgriculturaldroneandMav.mav;
public class driverPart1 {
	
	/**
	 * @returns the array copy
	 * 
	 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/**
		  * Creations of entries for FlyingObject Array
		  */
		
		airplane a1= new airplane("Boeing",2500000,400);
		airplane a2 = new airplane("Gulfstream",220000,410);
		airplane a3 = new airplane("Bombarder", 2350000,395);
		helicopter h1 = new helicopter("Boeing",1000000,250,4,2008,10);
		helicopter h2 = new helicopter("Boeing",1100000,275,6,2005,8);
		quadcopter q1 = new quadcopter ("DJI",2000,100,2,2013,0,600);
		quadcopter q2 = new quadcopter ("EHang",80000,101,4,2017,1,150);
		multirotor m1= new multirotor("Boeing",46000,98,2,2010,6,4);
		multirotor m2= new multirotor("Parrot",52000,105,2,2011,3,8);
		UAV u1 = new UAV(101.56,429000);
		UAV u2 =  new UAV(101.21,431000);
		agriculturaldrone ad1 =  new agriculturaldrone(89.45,30000,"HAL",10);
		agriculturaldrone ad2 = new agriculturaldrone(90.01,295000,"HAL",9);
		mav ma1 = new mav(43.25, 150000, "Parrot",5);
		mav ma2 = new mav(43.24, 151000,"Parrot",4.83);
		System.out.println(a1);
		System.out.println(h1);
		System.out.println(q1);
		System.out.println(m1);
		System.out.println(u1);
		System.out.println(ad1);
		System.out.println(ma1);
		System.out.println();
		
		FlyingObject[] fo=new FlyingObject[15] ;
		fo[0]=a1;
		fo[1]=a2;
		fo[2]=a3;
		fo[3]=h1;
		fo[4]=h2;
		fo[5]=q1;
		fo[6]=q2;
		fo[7]=m1;
		fo[8]=m2;
		fo[9]=u1;
		fo[10]=u2;
		fo[11]=ad1;
		fo[12]=ad2;
		fo[13]=ma1;
		fo[14]=ma2;
		
		/**
		 * Comparing two object
		 */
		System.out.println();
		
		System.out.println("It is "+fo[0].equals(fo[1])+" taht these two flying object is same.");
		System.out.println();
		int i1=0;
		int i2=0;
		double min1=Double.MAX_VALUE,min2=min1;
	
		for(int j=0;j<fo.length;j++) {
			FlyingObject fo1=fo[j];
			if(fo1.getPrice()<min1) {
				min2=min1;
				min1=fo1.getPrice();
				i2=i1;
				i1=j;
			}
			else if(fo1.getPrice()<min2) {
				i2=j;
				min2=fo1.getPrice();
			}
		}
		System.out.println("Least expensive object information:");
		System.out.println("Location: "+i1);
		System.out.println(fo[i1]);
		System.out.println("Least expensive object information:");
		System.out.println("Location: "+i2);
		System.out.println(fo[i2]);
		

		

		

		

		

		

		
	}
}