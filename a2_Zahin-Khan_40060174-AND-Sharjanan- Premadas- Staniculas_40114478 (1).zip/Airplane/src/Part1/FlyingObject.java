package Part1;

public class FlyingObject {
    protected double price;

    /**
	 * Default constructor
	 * 
	 */
    
    public FlyingObject() {

    }

    /**
	 * Copy constructor
	 * 
	 */
    public double getPrice() {
        return price;
    }

    public void setPrice() {
        this.price=price;
    }


}
