// -------------------------------------------------------
//Name(s) and ID(s) Sharjanan Premadas Staniculas(40114478) Zahin Khan(40060174)
//COMP249
//Assignment # 2
//Due Date Friday, October 23, 2020
 //----------------------------------------------------
/**
 * Name(s) and ID(s) Sharjanan Premadas Staniculas(40114478) Zahin Khan(40060174)
 * COMP249
 * Assignment # 2
 * Due Date Friday, October 23, 2020
 * This program stores data of different type of flying object and helps understand why the clone methode should be used over the 
 * copy constructor.
 */
/**
 * This java file is in the Airplane package and importing super class FlyingObject
 */
package Airplane;
import Part1.FlyingObject;

/**
 * 
 * airplane is a subclass of Flying object
 *
 */
public class airplane extends FlyingObject {
	/**
	 * Declaring Attributes
	 * @param brand is manufacturing company
	 * @param price is the cost of the airplanes
	 * @param horsepower is the power of airplanes's engine
	 */

	protected String brand;
	protected double price;
	protected int horsepower;
	/**
	 * Default constructor
	 */
	public airplane() {
		brand="";
		price=0;
		horsepower=0;
	}
	/**
	 * Constructor that takes 3 values
	 * @param brand is manufacturing company
	 * @param price is the cost of the airplanes
	 * @param horsepower is the power of engine
	 */
	
	public airplane(String brand,double price, int horsepower) {
		this.brand=brand;
		this.price=price;
		this.horsepower=horsepower;
	}
	/**
	 * Copy Constructor
	 * @parm o used as an object for copy constructor
	 */
	public airplane(airplane o) {
		this.brand = o.brand;
		this.price=o.price;
		this.horsepower=o.horsepower;
	}
	/**
	*accessors(getters) for the following variables (brand name,  price of airplanes and horsepower of engine)
	*@return the name of brand
	*@return the price of the appliance
	*@return the horsepower of the type of engine
	*/	

	public String getBrand() {
		return brand;
	}
	
	public double getPrice() {
		return price;
	}
	
	public int getHorsepower() {
		return horsepower;
	}
	/**
	*mutators(setters)for the following variables  (brand name,  price of airplanes and horsepower of engine)
	* @param brand is manufacturing company
	 * @param price is the cost of the airplanes
	 * @param horsepower is the power of engine
	*/	

	
	public void setBrand(String brand) {
		this.brand =brand;
	}
	
	public void setPrice(double price) {
		this.price=price;
	}
	
	public void setHorsepower(int horsepower) {
		this.horsepower = horsepower;
	}
	
	
	public String toString() {
		return "This airplane is manufactured by" + brand + ". It has a price of "+price+" with a horse power of "+horsepower+".";
	}
	/**
	 * Comparing the airplanes based on brand name, price and horsepower with the following method
	 * @Override equals method
	 * @return true or false
	 */

	public boolean equals(airplane o1) {
		if (this==o1)
			return true;
		if(o1==null)
			return false;
		if(getClass() !=o1.getClass())
			return false;
		airplane other = (airplane) o1;
		if (brand== null) {
			if (other.brand != null)
				return false;
		} else if (!brand.equals(other.brand))
			return false;
		if (horsepower != other.horsepower)
			return false;
		if(Double.doubleToLongBits(price)!=Double.doubleToLongBits(other.price))
			return false;
		return true;
	}
}