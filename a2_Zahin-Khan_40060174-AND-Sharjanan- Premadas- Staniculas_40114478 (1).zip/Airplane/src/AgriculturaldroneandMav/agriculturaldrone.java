//-------------------------------------------------------
//Name(s) and ID(s) Sharjanan Premadas Staniculas(40114478) Zahin Khan(40060174)
//COMP249
//Assignment # 2
//Due Date Friday, October 23, 2020
//----------------------------------------------------
/**
* Name(s) and ID(s) Sharjanan Premadas Staniculas(40114478) Zahin Khan(40060174)
* COMP249
* Assignment # 2
* Due Date Friday, October 23, 2020
 * This program stores data of different type of flying object and helps understand why the clone methode should be used over the 
 * copy constructor.
*/
/**
* This java file is in the AgriculturaldroneandMav package and importing super class UAv
*/
package AgriculturaldroneandMav;
import UAV.UAV;
/**
 * 
 * agriculturaldrone is a subclass of UAV
 *
 */
public class agriculturaldrone extends UAV {
/**
 * Declaring Attributes
 * @param brand is the brand Agricultural Drone
 * @param carrycapacity is the amount of weight it can carry
 */
	protected String brand;
	protected int carrycapacity;
/**
 * Default constructor
 */
	
	public agriculturaldrone() {
		super();
	}
	
	/**
	 * Super constructor
	 * @param weight is the weight of the UAV
	 * @param price of UAV
	 * @param brand of drone
	 * @param carrycapacity of drone
	 */
	public agriculturaldrone(double weight, double price, String brand, int carrycapacity) {
		super(weight,price);
		this.brand =brand;
		this.carrycapacity =carrycapacity;
	}
	/**
	 * Copy Constructor
	 * @param a is the drone object
	 */
	public agriculturaldrone(agriculturaldrone a) {
		super(a);
		this.brand = a.brand;
		this.carrycapacity = a.carrycapacity;
	}
	/**
	 * Accessors
	 * @return brand
	 * @return carrycappacity
	 * 
	 */
	public String getBrand() {
		return brand;
	}
	
	public int getCarrycapacity() {
		return carrycapacity;
	}
	/**
	 * Mutators
	 * @param brand
	 */
	public void setBrand(String brand) {
		this.brand = brand;
	}
	
	public void setCarrycapacity() {
		this.carrycapacity = carrycapacity;
	}
	
	public String toString() {
		return "This Agricultural drone is manufactured by"+ brand+ ". It weights"+weight+"pounds, and costs "+price+"It can carry up to "+carrycapacity+"kg.";
		
	}
	/**
	 * Comparing two drone
	 * @Override equals method
	 * @return  true or false
	 */
	public boolean equals(agriculturaldrone o) {
		if (this == o)
			return true;
		if (!super.equals(o))
			return false;
		if(getClass()!= o.getClass())
			return false;
		agriculturaldrone other = (agriculturaldrone) o;
		if (brand == null) {
			if (other.brand != null)
				return false;
			} else if (!brand.contentEquals(other.brand))
				return false;
			if(carrycapacity != other.carrycapacity)
				return false;
			return true;
		
	}
	
}