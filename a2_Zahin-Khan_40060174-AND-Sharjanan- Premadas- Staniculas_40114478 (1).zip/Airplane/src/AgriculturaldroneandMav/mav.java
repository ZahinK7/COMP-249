// -------------------------------------------------------
//Name(s) and ID(s) Sharjanan Premadas Staniculas(40114478) Zahin Khan(40060174)
//COMP249
//Assignment # 2
//Due Date Friday, October 23, 2020
 //----------------------------------------------------
/**
 * Name(s) and ID(s) Sharjanan Premadas Staniculas(40114478) Zahin Khan(40060174)
 * COMP249
 * Assignment # 2
 * Due Date Friday, October 23, 2020
 * This program stores data of different type of flying object and helps understand why the clone methode should be used over the 
 * copy constructor.
 */
/**
 * This java file is in the agriculturaldroneandMav package and importing super class UAV
 */
package AgriculturaldroneandMav;

import UAV.UAV;
/**
 * mav is a subclass of UAV
 */
public class mav extends UAV {
/**
 * Declaring Attributes 
 * @param model is the model of mav
 * @param size is the size of mav
 */
	protected String model;
	protected double size;
	
	public mav() {
		super();
	}
	
	public mav(double weight, double price, String model, double size) {
		super(weight,price);
		this.model = model;
		this.size=size;
	}
	
	public mav(mav m1) {
		super(m1);
		this.model=m1.model;
		this.size=m1.size;
	}
	
	public String getModel() {
		return model;
	}
	
  public double getSize() {
	  return size;
  }
  
  public void setModel(String model) {
	  this.model = model;
  }
  
  public void setSize(double size) {
	  this.size= size;
  }
  
  /**
   * @Override toString method
   * @return a message
   */
  public String toString () {
	 return "This MAV is the model"+ model+"with a price" +price+"and a weights"+weight+"pounds. It is"+size+"centimeters.";
  }
  /**
   * comparing two mav
   * @Override equals methode
   *@return true or false
   */
  public boolean equals(mav o) {
	  if (this ==o)
		  return true;
	  if(!super.equals(o))
		  return false;
	  if(getClass()!= o.getClass())
		  return false;
	  mav other = (mav) o;
	  if (model == null) {
		  if (other.model !=null)
			  return false;
	  }else if (!model.contentEquals(other.model))
		  return false;
	  if (Double.doubleToLongBits(size)!=Double.doubleToLongBits(other.size))
		  return false;
	  return true;
  }
  
  
}
