package Helicopter;
/**
 * 
 * Default constructor
 *
 */

public class quadcopter extends helicopter {
	protected int maxflyingspeed;
	public quadcopter() {
		super();
	}
	/**
	 * Parameterized Constructor
	 */
	public quadcopter(String brand,double price,int horsepower,int numberofcylinders,int creationyear,int passengercapacity, int maxflyingspeed) {
		super(brand, price, horsepower,numberofcylinders,creationyear,passengercapacity);
		 this.maxflyingspeed = maxflyingspeed;
	}
	
	public quadcopter(quadcopter q) {
		super(q);
		this.maxflyingspeed = q.maxflyingspeed;
	}
	
	public int getMaxflyingspeed() {
		return maxflyingspeed;
	}
	/**
	 * ToString method
	 */
	public String toString() {
		return "This Quadcopter was made by"+ brand + ". It has a price of "+price+ "and was made in "+creationyear+".It has "+numberofcylinders+"cylinders,with a horse power of "+
	horsepower+"and can carry"+passengercapacity+"passengers. It has "+maxflyingspeed+ "as its max speed.";
	}
	
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!super.equals(o))
			return false;
		if (getClass()!=o.getClass())
			return false;
		quadcopter other = (quadcopter)o;
		if (maxflyingspeed != other.maxflyingspeed)
			return false;
		return true;
	}
	
	
	
	
}
