package Helicopter;

import Airplane.airplane;

public class helicopter extends airplane {

	protected int numberofcylinders;
	protected int creationyear;
	protected int passengercapacity;
	/**
	 * Default constructor
	 */
	public helicopter() {
		super();
	}
	/**
	 * Parameterized Constructor
	 * @param brand
	 * @param price
	 * @param horsepower
	 * @param numberofcylinders
	 * @param creationyear
	 * @param passengercapacity
	 */
	
	public helicopter(String brand, double price, int horsepower, int numberofcylinders,int creationyear, int passengercapacity) {
		super(brand, price, horsepower);
		this.numberofcylinders = numberofcylinders;
		this.creationyear=creationyear;
		this.passengercapacity= passengercapacity;
		
	}
	
	public helicopter(helicopter h1) {
		super(h1);
		this.numberofcylinders = h1.numberofcylinders;
		this.creationyear = h1.creationyear;
		this.passengercapacity = h1.passengercapacity;
		
	}

	public int getNumberofcylinders() {
		return numberofcylinders;
	}
	
	public int getCreationyear() {
		return creationyear;
	}
	
	public int getPassengercapacity() {
		return passengercapacity;
	}
	
	public void setNumberofcylinders(int numberofcylinders) {
		this.numberofcylinders = numberofcylinders;
	}
	
	public void setCreationyear(int creationyear) {
		this.creationyear = creationyear;
	}
	
	public void setPassengercapacity(int passengercapacity) {
		this.passengercapacity=passengercapacity;
	}
	
	public String toString() {
		return "This helicopter was made by" +brand+ ".It has a price of "+price+ "and was made in "+creationyear+"It has "+numberofcylinders+"cylinders, with a horse power of "+horsepower+"and can carry "+passengercapacity+"passengers.";
	}
	/**
	 * ToString method used
	 */
	public boolean equals(Object o3) {
		if (this == o3)
			return true;
		if (!super.equals(o3))
			return false; 
		if (getClass()!=o3.getClass())
			return false ;
		helicopter other = (helicopter) o3;
		if (creationyear != other.creationyear)
			return false;
		if(numberofcylinders != other.numberofcylinders)
			return false;
		if(passengercapacity != other.passengercapacity)
			return false;
		return true;
	}
}
