// -----------------------------------------------------
// Part: 2
// Written by:Zahin Khan (40060174) and Sharjanan Premadas (440114478)
// -----------------------------------------------------
/**
 * Name(s) and ID(s) Sharjanan Premadas Staniculas(40114478) Zahin Khan(40060174)
 * COMP249
 * Assignment # 1
 * Due Date Friday, October 02, 2020
 * This program allows the use of attributes and methods of appliance in order to compare or store information
 */

package Part2;

public class FlyingObject {
	protected double price;
	
	/**
	 * Default constructor
	 * 
	 */
	
	public FlyingObject() {
		price=0;
	}
	
	/**
	 * Copy constructor
	 * 
	 */
	
	public FlyingObject(double p) {
		price=p;
	}
	public FlyingObject(FlyingObject fo) {
		price=fo.price;
		
	}
	
	public double getPrice() {
		return price;
	}
	
	public void setPrice() {
		this.price=price;
	}
	

}
