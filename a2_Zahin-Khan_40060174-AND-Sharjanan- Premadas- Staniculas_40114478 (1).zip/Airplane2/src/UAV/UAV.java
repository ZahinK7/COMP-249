package UAV;
import Part2.FlyingObject;

public class UAV extends FlyingObject {
	
	/**
	 * Declaring Attributes
	 * @param weight is the weight of UAV
	 * @param price is the price of the UAV
	 */
	
	protected double weight;
	protected double price;
	
	/**
	 * Default constructor
	 */
	public UAV() {
		
	}
	/**
	 * Constructor that take 2 values
	 * @param weight is the weight of UAV
	 * @param price is the price of the UAV
	 */
	public UAV(double weight, double price) {
		this.weight = weight;
		this.price = price;
	}
	/**
	 * Copy Constructor
	 * @param u1 is the object UAv used to do the copy constructor
	 */
	
	public UAV(UAV u1) {
		this.weight = u1.weight;
		this.price=u1.price;
	}
	
	public double getWeight() {
		return weight;
	}
	
	public double getPrice() {
		return price;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	public void setPrice(double price) {
		this.price=price;
	}
	/**
	 * @return a message with price and weight
	 */
	public String toString() {
		return "This UAV has a weight of "+weight+"pounds and a price of "+price+".";
	}
	/**
	 *@return if two UAV are the same by considering the weight and price
	 */
	public boolean equals(Object o) {
		if(this == o)
			return true;
		if(o==null)
			return false;
		if (getClass()!= o.getClass())
			return false;
		UAV other = (UAV) o;
		if (Double.doubleToLongBits(price)!=Double.doubleToLongBits(other.price))
			return false;
		if (Double.doubleToLongBits(weight)!=Double.doubleToLongBits(other.weight))
			return false;
		return true;
		
	}
}
