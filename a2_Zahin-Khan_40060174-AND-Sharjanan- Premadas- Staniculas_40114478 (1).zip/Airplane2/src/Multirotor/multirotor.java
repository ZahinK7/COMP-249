// -----------------------------------------------------
// Part: 2
// Written by: Zahin Khan (40060174) and Sharjanan Premadas (40114478)
// -----------------------------------------------------

/**
 * Name(s) and ID(s) Sharjanan Premadas Staniculas(40114478) Zahin Khan(40060174)
 * COMP249
 * Assignment # 1
 * Due Date Friday, October 02, 2020
 * This program allows the use of attributes and methods of appliance in order to compare or store information
 */

package Multirotor;


import Helicopter.helicopter;

public class multirotor extends helicopter{
	
	protected int numberofrotors;
	
	/**
	 * Default constructor
	 * 
	 */
	public multirotor() {
		super();
	}

	/**
	 * Parameterized Constructor
	 */
	
	public multirotor(String brand,double price,int horsepower,int numberofcylinders,int creationyear,int passengercapacity, int numberofrotors) {
		super(brand, price, horsepower,numberofcylinders,creationyear,passengercapacity);
		 this.numberofrotors = numberofrotors;
	}
	
	/**
	 * 
	 * Copy Constructor
	 */
	public multirotor(multirotor m) {
		super(m);
		this.numberofrotors = m.numberofrotors;
	}
	
	public int getNumberofrotors() {
		return numberofrotors;
	}
	
	
	
	public String toString() {
		return "This Multirotor was made by"+ brand + ". It has a price of "+price+ "and was made in "+creationyear+".It has "+numberofcylinders+"cylinders,with a horse power of "+
	horsepower+"and can carry"+passengercapacity+"passengers. It has "+numberofrotors+ "rotors.";
	}
	
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!super.equals(o))
			return false;
		if (getClass()!=o.getClass())
			return false;
		multirotor other = (multirotor)o;
		if (numberofrotors != other.numberofrotors)
			return false;
		return true;
	}
}
